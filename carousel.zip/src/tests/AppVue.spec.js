import App from '../App.vue';
import { shallowMount } from '@vue/test-utils';

describe('Mounted App', () => {
    test('App', () => {
        // render the component
        global.$ = jest.fn();
        // window.$ = jest.fn();
        const wrapper = shallowMount(App);
        expect(wrapper.isVueInstance()).toBeTruthy();
    })
});