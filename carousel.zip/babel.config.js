module.exports = {
  presets: [
    '@vue/app',
    "@babel/env"
  ]
}
